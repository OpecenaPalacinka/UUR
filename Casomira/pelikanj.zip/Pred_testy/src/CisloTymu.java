public enum CisloTymu {
    Tym1,Tym2
}
